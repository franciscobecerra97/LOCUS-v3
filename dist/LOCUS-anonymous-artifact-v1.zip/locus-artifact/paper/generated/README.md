# Generated Paper Inputs

This directory contains only the table inputs derived from the retained v2
performance corpus:

```text
performance-v2/latency_rows.tex
performance-v2/phase_rows.tex
performance-v2/traffic_rows.tex
performance-v2/storage_rows.tex
performance-v2/manifest.json
```

Regenerate and verify the bundle from the artifact root:

```console
uv run --frozen python tasks.py process-performance --verify
uv run --frozen python tasks.py generate-performance-paper
```

The generator accepts only the canonical processed result at
`experiments/processed/performance-v2/summary.json`. The manifest binds the
processed-source digest, experiment identifier, source revision, pseudonymous
host, processing configuration, and digest of every row file. Identical
regeneration is idempotent; the artifact command does not replace changed
outputs silently.

The complete manuscript and LaTeX support package are intentionally outside
the artifact. These generated fragments are included solely to connect the
retained measurements to the reported tables.
