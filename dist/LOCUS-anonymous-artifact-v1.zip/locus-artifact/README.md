# LOCUS Anonymous Artifact

This repository contains the anonymized research artifact accompanying the
LOCUS paper. LOCUS studies distributed private-key recovery in which a client
uses a standardized cue policy to derive TPASS input, an object store retains
only an encrypted backup, and separately identified recovery-party services
hold threshold protocol state.

The artifact provides the implementation, synthetic fixtures, tests, retained
aggregate experiment records, deterministic result-processing pipeline, and
generated table inputs needed to inspect and reproduce the reported system
results. It contains no real recovery data or original human-subject data.

LOCUS is a research prototype. It is not production-ready, independently
audited, or suitable for real private keys or personal recovery information.

## Start here

1. Read [`artifact/INSTALL.md`](artifact/INSTALL.md) for prerequisites and
   setup.
2. Read [`artifact/EVALUATION.md`](artifact/EVALUATION.md) for the evaluation
   commands and expected observations.
3. Read [`artifact/MANIFEST.md`](artifact/MANIFEST.md) for the inclusion,
   provenance, and privacy boundary.

The shortest local verification path is:

```console
uv sync --frozen
uv run --frozen python tasks.py check
uv run --frozen python tasks.py artifact-smoke
```

Docker is required only for the live S3-compatible and complete same-host
deployment profiles.

## Repository layout

| Path | Purpose |
| --- | --- |
| `prototype/` | Python orchestration, storage adapters, recovery services, tests, and evaluation commands |
| `tpass-core/` | Rust/Ristretto255 TPASS implementation and fixed vectors |
| `tpass-python/` | PyO3 binding between the Rust protocol and Python |
| `deploy/` | Isolated same-host deployment and synthetic resolver fixture |
| `experiments/raw/` | Retained aggregate-only attack and performance records |
| `experiments/processed/` | Deterministic summary derived from the retained performance records |
| `paper/generated/` | Manifest-bound LaTeX table rows derived from the processed summary |
| `docs/schemas/` | Machine-readable schemas for experiment and evaluation records |
| `artifact/` | Installation, evaluation, and package-boundary documentation |
| `tasks.py` | Cross-platform entry point for build, test, and evaluation commands |

## Implemented evaluation profile

The packaged profile combines:

- the exact three-pair `LOCUS-location-person-set-v1` reference cue policy;
- native 2-of-3 TPASS recovery over Ristretto255;
- AES-256-GCM backup encryption with HKDF-SHA-256 key derivation;
- a bounded immutable S3-compatible backup object;
- five separately identified same-host recovery-party processes with distinct
  state and authenticated local transport;
- deterministic synthetic resolver records;
- durable local attempt-ledger and exact-retry instrumentation; and
- aggregate-only performance and snapshot-boundary experiments.

The three retained snapshot scenarios inspect:

- the encrypted cloud object and its public locator/integrity metadata;
- one recovery party's stopped persistent state in the deployed 2-of-3
  profile; and
- the exact matching union of those cloud and one-party snapshots.

Each scenario uses two fixed synthetic candidates in a credential-free,
read-only, networkless process. The retained records report aggregate
observations only. They do not contain candidate values, per-candidate results,
credentials, snapshots, databases, or service logs.

The retained same-host performance corpus contains ten randomized blocks and
30 measurements for each of three scenarios: successful enrollment and
recovery, recovery with one party unavailable, and wrong-input rejection.
`tasks.py process-performance --verify` regenerates the processed result in
memory and checks it byte-for-byte. `tasks.py generate-performance-paper`
verifies that the packaged table inputs remain unchanged.

## Interpretation boundary

The artifact supports reproduction of the exact tested architecture,
deterministic cue-policy processing, state-separation checks, snapshot
observations, failure behavior, and same-host measurements.

It does not establish:

- human memorability, usability, or entropy for the reference cue policy;
- a rollback-resistant global recovery-attempt bound;
- public recovery admission or safe lockout reset;
- independently administered or multi-host recovery parties;
- security against threshold compromise, endpoint compromise, or leaked
  wrapping/group secrets;
- Internet-scale performance, scalability, concurrency, or geographic
  behavior; or
- production security or an independent cryptographic audit.

The bounded attempt-control model intentionally reproduces counterexamples for
quorum-only rollback handling. Its ideal-anchor comparison reports no
counterexample only within the declared finite search bounds; this is not a
proof.

## Privacy and safety

All examples and evaluations use generated keys, generated credentials, and
fictional cue records. Normal output is scanned for prohibited secret-bearing
material. Docker-backed evaluations use exact disposable project names and
remove their containers, networks, and volumes after completion.

Do not use this artifact with real private keys, credentials, accounts,
personal cues, production services, or external targets.

## Licensing

Project-authored software and configuration are licensed under Apache License
2.0. Project-authored documentation and aggregate experiment material are
licensed under Creative Commons Attribution 4.0 International with
`LOCUS Authors` as the designated attribution. See `LICENSE`,
`LICENSE-DOCUMENTATION.md`, and `LICENSES.md`.
