# LOCUS Reference Prototype

The reference prototype provides Python orchestration around the native
Rust/Ristretto255 TPASS implementation, pinned-library HKDF-SHA-256 and
AES-256-GCM backup cryptography, immutable object-store adapters, authenticated
same-host recovery-party services, synthetic fixtures, and regression tests.

The simulator and fixed safe-prime toy backend are explicitly labeled testing
options. They are not used for the retained native performance results. No
backend is independently audited or production-ready.

## Layout

```text
prototype/
  locus/          implementation modules
  scripts/        demo, walkthrough, and benchmark entry points
  test-vectors/   deterministic cue-policy and resolver-drift vectors
  tests/          unit, integration, failure, and artifact tests
```

Important implementation modules include:

- `core.py`: LOCUS enrollment and recovery flow;
- `cue_policy.py`: exact reference cue-policy canonicalization;
- `tpass.py`: native adapter plus explicit simulator and toy backends;
- `crypto.py`: backup encryption and wrapping-key derivation;
- `object_store.py` and `s3_object_store.py`: immutable backup storage;
- `party_store.py`, `party_service.py`, and `party_http.py`: durable party state
  and authenticated local protocol handling;
- `deployment.py`: isolated deployment provisioning and boundary checks;
- `attempt_model.py`: bounded attempt-control counterexample exploration; and
- `performance_processing.py`: deterministic retained-result processing.

## Verification

Run from the artifact root:

```console
uv sync --frozen
uv run --frozen python tasks.py check
uv run --frozen python tasks.py artifact-smoke
```

Optional Docker-backed paths:

```console
uv run --frozen python tasks.py s3-smoke
uv run --frozen python tasks.py deployment-smoke
```

The interactive walkthrough accepts only numbered fictional cue pairs,
generates its own test key, prints redacted stage summaries, and writes no
protocol state:

```console
uv run --frozen python tasks.py walkthrough
```

The artifact uses generated credentials, temporary databases, synthetic cue
records, and disposable same-host containers. Do not supply real private keys,
accounts, credentials, or personal recovery data.
