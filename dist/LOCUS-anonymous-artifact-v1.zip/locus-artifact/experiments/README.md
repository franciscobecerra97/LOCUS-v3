# LOCUS Experiment Data

This directory contains the privacy-safe experiment material distributed with
the artifact:

- `raw/` contains immutable, schema-validated aggregate records from the
  snapshot and same-host performance evaluations.
- `processed/` contains a deterministic summary derived from the retained
  performance records.

No record contains credentials, secret protocol state, real cue data,
candidate values, per-candidate outcomes, snapshots, databases, service logs,
packet captures, core dumps, or exception traces.

Run the verification pipeline from the artifact root:

```console
uv run --frozen python tasks.py process-performance --verify
uv run --frozen python tasks.py generate-performance-paper
```
